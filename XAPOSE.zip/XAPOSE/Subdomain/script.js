document.getElementById('searchButton').addEventListener('click', function() {
    const domain = document.getElementById('domain').value.trim();

    if (domain) {
        findSubdomains(domain);
    } else {
        alert("Please enter a valid domain.");
    }
});

function findSubdomains(domain) {
    const resultsContainer = document.getElementById('results');
    resultsContainer.innerHTML = '';  // Clear previous results

    // Simulate subdomain search by using a predefined list of common subdomains
    const subdomainList = [
        'www', 'api', 'mail', 'dev', 'blog', 'ftp', 'shop', 'secure', 'm', 'app', 'admin', 'support', 'test', 'staging'
    ];

    const foundSubdomains = subdomainList.map(subdomain => `${subdomain}.${domain}`);
    
    // Show results
    if (foundSubdomains.length > 0) {
        const list = document.createElement('ul');
        list.classList.add('space-y-2');
        
        foundSubdomains.forEach(subdomain => {
            const listItem = document.createElement('li');
            listItem.classList.add('bg-gray-200', 'p-3', 'rounded', 'shadow-sm');
            listItem.textContent = subdomain;
            list.appendChild(listItem);
        });

        resultsContainer.appendChild(list);
    } else {
        resultsContainer.innerHTML = '<p class="text-center text-gray-600">No subdomains found.</p>';
    }
}
